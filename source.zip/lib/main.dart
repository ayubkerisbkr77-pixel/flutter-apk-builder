import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:geolocator/geolocator.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Location App',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const LocationHomePage(),
    );
  }
}

class LocationHomePage extends StatefulWidget {
  const LocationHomePage({super.key});

  @override
  State<LocationHomePage> createState() => _LocationHomePageState();
}

class _LocationHomePageState extends State<LocationHomePage> {
  String _status = "Meminta izin lokasi...";

  @override
  void initState() {
    super.initState();
    // Minta izin lokasi begitu halaman pertama tampil
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _requestLocationPermission();
    });
  }

  Future<void> _requestLocationPermission() async {
    final status = await Permission.location.request();

    if (status.isGranted) {
      setState(() => _status = "Izin lokasi diberikan. Mengambil lokasi...");
      _getCurrentLocation();
    } else if (status.isPermanentlyDenied) {
      setState(() =>
          _status = "Izin lokasi ditolak permanen. Membuka pengaturan...");
      openAppSettings();
    } else {
      setState(() => _status = "Izin lokasi ditolak oleh pengguna.");
    }
  }

  Future<void> _getCurrentLocation() async {
    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        setState(() => _status = "GPS/layanan lokasi belum aktif.");
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        locationSettings:
            const LocationSettings(accuracy: LocationAccuracy.high),
      );
      setState(() =>
          _status = "Lat: ${position.latitude}, Lon: ${position.longitude}");
    } catch (e) {
      setState(() => _status = "Gagal mengambil lokasi: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Location App')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(_status, textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 16)),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _requestLocationPermission,
                child: const Text("Minta Izin Lagi"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
