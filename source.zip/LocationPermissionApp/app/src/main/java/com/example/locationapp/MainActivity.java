package com.example.locationapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    // Kode request permission (angka bebas, dipakai untuk identifikasi callback)
    private static final int REQUEST_LOCATION_CODE = 100;

    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.statusText);

        // Cek dan minta izin lokasi begitu aplikasi dibuka
        checkAndRequestLocationPermission();
    }

    private void checkAndRequestLocationPermission() {
        // Cek apakah izin sudah diberikan sebelumnya
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Belum ada izin -> tampilkan dialog permintaan izin ke pengguna
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                    },
                    REQUEST_LOCATION_CODE
            );
        } else {
            // Izin sudah ada sebelumnya
            statusText.setText("Izin lokasi sudah diberikan.");
            getLastKnownLocation();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                            @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_LOCATION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Pengguna menekan "Izinkan"
                Toast.makeText(this, "Izin lokasi diberikan", Toast.LENGTH_SHORT).show();
                statusText.setText("Izin lokasi diberikan. Mengambil lokasi...");
                getLastKnownLocation();
            } else {
                // Pengguna menekan "Tolak"
                Toast.makeText(this, "Izin lokasi ditolak", Toast.LENGTH_SHORT).show();
                statusText.setText("Izin lokasi ditolak oleh pengguna.");
            }
        }
    }

    private void getLastKnownLocation() {
        // Pastikan izin sudah ada sebelum akses lokasi (menghindari crash/lint warning)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (locationManager != null) {
            Location location = null;
            try {
                location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (location == null) {
                    location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                }
            } catch (SecurityException e) {
                statusText.setText("Gagal mengambil lokasi: izin tidak lengkap.");
                return;
            }

            if (location != null) {
                String coords = "Lat: " + location.getLatitude() + ", Lon: " + location.getLongitude();
                statusText.setText(coords);
            } else {
                statusText.setText("Lokasi belum tersedia. Coba aktifkan GPS.");
            }
        }
    }
}
